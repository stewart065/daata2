﻿using System;
using System.Collections.Generic;

namespace sampleMVC.Entities
{
    public partial class AnotherTable
    {
        public int Id { get; set; }
        public int Asadfsdf { get; set; }
    }
}
